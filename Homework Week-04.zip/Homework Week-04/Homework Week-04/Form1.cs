﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework_Week_04
{
    public partial class Form1 : Form
    {
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
            dt = new DataTable();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Negara");
            dt.Columns.Add("Team");
            dt.Columns.Add("No");
            dt.Columns.Add("nama");
            dt.Columns.Add("role");
            dt.Rows.Add("Indonesia", "Persebaya", "21", "Ernando Ari Sutaryadi", "GK");
            dt.Rows.Add("Indonesia", "Persebaya", "52", "Andhika Ramadhani", "GK");
            dt.Rows.Add("Indonesia", "Persebaya", "26", "Silva Paixao Yan Victor", "DF");
            dt.Rows.Add("Indonesia", "Persebaya", "42", "Arief Catur Prasetya", "DF");
            dt.Rows.Add("Indonesia", "Persebaya", "5", "Dusan Stevanovic", "DF");
            dt.Rows.Add("Indonesia", "Persebaya", "96", "Muhammad Hidayat", "MF");
            dt.Rows.Add("Indonesia", "Persebaya", "8", "Andre Oktaviansyah", "MF");
            dt.Rows.Add("Indonesia", "Persebaya", "28", "Alfan Suaib", "MF");
            dt.Rows.Add("Indonesia", "Persebaya", "30", "Robson Duarte", "FW");
            dt.Rows.Add("Indonesia", "Persebaya", "9", "Paulo Henrique", "FW");
            dt.Rows.Add("Indonesia", "Persebaya", "99", "Bruno Moreira Soares", "FW");
            dt.Rows.Add("Indonesia", "Arema FC", "23", "Teguh Amirrudin", "GK");
            dt.Rows.Add("Indonesia", "Arema FC", "22", "Dicki Agung", "GK");
            dt.Rows.Add("Indonesia", "Arema FC", "5", "Bagas Adi", "DF");
            dt.Rows.Add("Indonesia", "Arema FC", "4", "Syaeful Anwar", "DF");
            dt.Rows.Add("Indonesia", "Arema FC", "3", "Bayu Aji", "DF");
            dt.Rows.Add("Indonesia", "Arema FC", "14", "Jayus Hariono", "MF");
            dt.Rows.Add("Indonesia", "Arema FC", "8", "Arkhan Fikri", "MF");
            dt.Rows.Add("Indonesia", "Arema FC", "19", "Achmad Maulana", "MF");
            dt.Rows.Add("Indonesia", "Arema FC", "10", "Muhammad Rafli", "FW");
            dt.Rows.Add("Indonesia", "Arema FC", "17", "Ginanjar Wahyu", "FW");
            dt.Rows.Add("Indonesia", "Arema FC", "86", "Greg Nwokolo", "FW");
            dt.Rows.Add("Britania Raya", "Liverpool", "1", "Alisson Becker", "GK");
            dt.Rows.Add("Britania Raya", "Liverpool", "13", "Adrian", "GK");
            dt.Rows.Add("Britania Raya", "Liverpool", "2", "Joe Gomez", "DF");
            dt.Rows.Add("Britania Raya", "Liverpool", "5", "Ibrahima Konate", "DF");
            dt.Rows.Add("Britania Raya", "Liverpool", "4", "Virgil Van Djik", "DF");
            dt.Rows.Add("Britania Raya", "Liverpool", "2", "Wateru Endo", "MF");
            dt.Rows.Add("Britania Raya", "Liverpool", "6", "Thiago Alcantara", "MF");
            dt.Rows.Add("Britania Raya", "Liverpool", "8", "Dominik Szobozslai", "MF");
            dt.Rows.Add("Britania Raya", "Liverpool", "7", "Luis Diaz", "FW");
            dt.Rows.Add("Britania Raya", "Liverpool", "9", "Darwin Nunez", "FW");
            dt.Rows.Add("Britania Raya", "Liverpool", "11", "Mohamed Salah", "FW");
        }

        private void cb_Country_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbTeam.Items.Clear();
            cbTeam.Text = string.Empty;
            lb_player.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][0] == cb_Country.SelectedItem)
                {
                    if (!cbTeam.Items.Contains(dt.Rows[i][1]))
                    {
                        cbTeam.Items.Add(dt.Rows[i][1]);
                    }
                }
            }
        }
        private void cb_Country_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < dt.Rows.Count; i++)
            {
                if (!cb_Country.Items.Contains(dt.Rows[i][0]))
                {
                    cb_Country.Items.Add(dt.Rows[i][0]);
                }
            }
        }

        private void cbTeam_SelectionChangeCommited(object sender, EventArgs e)
        {
            lb_player.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][1] == cbTeam.SelectedItem)
                {
                    lb_player.Items.Add("(" + dt.Rows[i][2] + ") " + dt.Rows[i][3] + ". " + dt.Rows[i][4]);
                }
            }
        }

        private void btn_RemovePlayer_Click(object sender, EventArgs e)
        {
            if (lb_player.Items.Count <= 11)
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error");

            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1] == cbTeam.SelectedItem)
                    {
                        dt.Rows.RemoveAt(lb_player.SelectedIndex + i);
                        lb_player.Items.Remove(lb_player.SelectedItem);
                        break;
                    }
                }
            }
        }

        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            if (tb_TeamName.Text.Length == 0)
            {
                MessageBox.Show("Semua harus terisi terlebih dahulu");
            }
            else if (tb_TeamCountry.Text.Length == 0)
            {
                MessageBox.Show("Semua harus terisi terlebih dahulu");
            }
            else if (tb_TeamCity.Text.Length == 0)
            {
                MessageBox.Show("Semua harus terisi terlebih dahulu");
            }
            else
            {
                bool ada = false;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (tb_TeamName.Text == dt.Rows[i][1].ToString())
                    {
                        MessageBox.Show("Nama sudah ada");
                        ada = true;
                        break;
                    }
                }
                if (ada == false)
                {
                    dt.Rows.Add(tb_TeamCountry.Text, tb_TeamName.Text, "", "", "");
                    tb_TeamName.Clear();
                    tb_TeamCountry.Clear();
                    tb_TeamCity.Clear();
                    lb_player.Items.Clear();
                    cb_Country.Text = string.Empty;
                    cbTeam.Items.Clear();
                    cbTeam.Text = string.Empty;
                }
            }
        }

        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            if (cbTeam.Text.Length == 0)
            {
                MessageBox.Show("Pilih tim terlebih dahulu");
            }
            else if (tb_PlayerName.Text.Length == 0)
            {
                MessageBox.Show("Semua harus terisi terlebih dahulu");
            }
            else if (tb_PlayerNumber.Text.Length == 0)
            {
                MessageBox.Show("Semua harus terisi terlebih dahulu");
            }
            else if (cb_PlayerPosition.Text.Length == 0)
            {
                MessageBox.Show("Semua harus terisi terlebih dahulu");
            }
            else
            {
                bool ada = false;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (tb_PlayerName.Text == dt.Rows[i][3].ToString())
                    {
                        MessageBox.Show("Nama pemain tidak boleh sama");
                        ada = true;
                        break;
                    }
                }
                if (ada == false)
                {
                    dt.Rows.Add(cb_Country.SelectedItem.ToString(), cbTeam.SelectedItem.ToString(), tb_PlayerNumber.Text.ToString(), tb_PlayerName.Text.ToString(), cb_PlayerPosition.SelectedItem.ToString());
                    lb_player.Items.Clear();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (dt.Rows[i][1] == cbTeam.SelectedItem)
                        {
                            lb_player.Items.Add("(" + dt.Rows[i][2] + ") " + dt.Rows[i][3] + ". " + dt.Rows[i][4]);
                        }
                    }
                    tb_PlayerName.Clear();
                    tb_PlayerNumber.Clear();
                    cb_PlayerPosition.Text = string.Empty;
                }
            }
        }
    }
}
