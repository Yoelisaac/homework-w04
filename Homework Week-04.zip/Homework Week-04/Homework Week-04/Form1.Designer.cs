﻿namespace Homework_Week_04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_SoccerTeamList = new System.Windows.Forms.Label();
            this.lbl_Country = new System.Windows.Forms.Label();
            this.lbl_Team = new System.Windows.Forms.Label();
            this.lbl_TeamName = new System.Windows.Forms.Label();
            this.lbl_TeamCountry = new System.Windows.Forms.Label();
            this.lbl_TeamCity = new System.Windows.Forms.Label();
            this.lbl_PlayerName = new System.Windows.Forms.Label();
            this.lbl_PlayerNumber = new System.Windows.Forms.Label();
            this.lbl_PlayerPosition = new System.Windows.Forms.Label();
            this.lbl_AddingTeam = new System.Windows.Forms.Label();
            this.lbl_AddingPlayers = new System.Windows.Forms.Label();
            this.tb_TeamName = new System.Windows.Forms.TextBox();
            this.tb_TeamCountry = new System.Windows.Forms.TextBox();
            this.tb_TeamCity = new System.Windows.Forms.TextBox();
            this.tb_PlayerName = new System.Windows.Forms.TextBox();
            this.tb_PlayerNumber = new System.Windows.Forms.TextBox();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.btn_RemovePlayer = new System.Windows.Forms.Button();
            this.cb_Country = new System.Windows.Forms.ComboBox();
            this.cbTeam = new System.Windows.Forms.ComboBox();
            this.cb_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.lb_player = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lbl_SoccerTeamList
            // 
            this.lbl_SoccerTeamList.AutoSize = true;
            this.lbl_SoccerTeamList.Location = new System.Drawing.Point(26, 55);
            this.lbl_SoccerTeamList.Name = "lbl_SoccerTeamList";
            this.lbl_SoccerTeamList.Size = new System.Drawing.Size(90, 13);
            this.lbl_SoccerTeamList.TabIndex = 0;
            this.lbl_SoccerTeamList.Text = "Soccer Team List";
            // 
            // lbl_Country
            // 
            this.lbl_Country.AutoSize = true;
            this.lbl_Country.Location = new System.Drawing.Point(26, 84);
            this.lbl_Country.Name = "lbl_Country";
            this.lbl_Country.Size = new System.Drawing.Size(85, 13);
            this.lbl_Country.TabIndex = 1;
            this.lbl_Country.Text = "Choose Country:";
            // 
            // lbl_Team
            // 
            this.lbl_Team.AutoSize = true;
            this.lbl_Team.Location = new System.Drawing.Point(26, 121);
            this.lbl_Team.Name = "lbl_Team";
            this.lbl_Team.Size = new System.Drawing.Size(76, 13);
            this.lbl_Team.TabIndex = 2;
            this.lbl_Team.Text = "Choose Team:";
            // 
            // lbl_TeamName
            // 
            this.lbl_TeamName.AutoSize = true;
            this.lbl_TeamName.Location = new System.Drawing.Point(296, 84);
            this.lbl_TeamName.Name = "lbl_TeamName";
            this.lbl_TeamName.Size = new System.Drawing.Size(68, 13);
            this.lbl_TeamName.TabIndex = 3;
            this.lbl_TeamName.Text = "Team Name:";
            // 
            // lbl_TeamCountry
            // 
            this.lbl_TeamCountry.AutoSize = true;
            this.lbl_TeamCountry.Location = new System.Drawing.Point(296, 121);
            this.lbl_TeamCountry.Name = "lbl_TeamCountry";
            this.lbl_TeamCountry.Size = new System.Drawing.Size(76, 13);
            this.lbl_TeamCountry.TabIndex = 4;
            this.lbl_TeamCountry.Text = "Team Country:";
            // 
            // lbl_TeamCity
            // 
            this.lbl_TeamCity.AutoSize = true;
            this.lbl_TeamCity.Location = new System.Drawing.Point(296, 158);
            this.lbl_TeamCity.Name = "lbl_TeamCity";
            this.lbl_TeamCity.Size = new System.Drawing.Size(57, 13);
            this.lbl_TeamCity.TabIndex = 5;
            this.lbl_TeamCity.Text = "Team City:";
            // 
            // lbl_PlayerName
            // 
            this.lbl_PlayerName.AutoSize = true;
            this.lbl_PlayerName.Location = new System.Drawing.Point(514, 84);
            this.lbl_PlayerName.Name = "lbl_PlayerName";
            this.lbl_PlayerName.Size = new System.Drawing.Size(70, 13);
            this.lbl_PlayerName.TabIndex = 6;
            this.lbl_PlayerName.Text = "Player Name:";
            // 
            // lbl_PlayerNumber
            // 
            this.lbl_PlayerNumber.AutoSize = true;
            this.lbl_PlayerNumber.Location = new System.Drawing.Point(514, 121);
            this.lbl_PlayerNumber.Name = "lbl_PlayerNumber";
            this.lbl_PlayerNumber.Size = new System.Drawing.Size(79, 13);
            this.lbl_PlayerNumber.TabIndex = 7;
            this.lbl_PlayerNumber.Text = "Player Number:";
            // 
            // lbl_PlayerPosition
            // 
            this.lbl_PlayerPosition.AutoSize = true;
            this.lbl_PlayerPosition.Location = new System.Drawing.Point(514, 158);
            this.lbl_PlayerPosition.Name = "lbl_PlayerPosition";
            this.lbl_PlayerPosition.Size = new System.Drawing.Size(79, 13);
            this.lbl_PlayerPosition.TabIndex = 8;
            this.lbl_PlayerPosition.Text = "Player Position:";
            // 
            // lbl_AddingTeam
            // 
            this.lbl_AddingTeam.AutoSize = true;
            this.lbl_AddingTeam.Location = new System.Drawing.Point(385, 55);
            this.lbl_AddingTeam.Name = "lbl_AddingTeam";
            this.lbl_AddingTeam.Size = new System.Drawing.Size(70, 13);
            this.lbl_AddingTeam.TabIndex = 9;
            this.lbl_AddingTeam.Text = "Adding Team";
            // 
            // lbl_AddingPlayers
            // 
            this.lbl_AddingPlayers.AutoSize = true;
            this.lbl_AddingPlayers.Location = new System.Drawing.Point(600, 55);
            this.lbl_AddingPlayers.Name = "lbl_AddingPlayers";
            this.lbl_AddingPlayers.Size = new System.Drawing.Size(77, 13);
            this.lbl_AddingPlayers.TabIndex = 10;
            this.lbl_AddingPlayers.Text = "Adding Players";
            // 
            // tb_TeamName
            // 
            this.tb_TeamName.Location = new System.Drawing.Point(370, 81);
            this.tb_TeamName.Name = "tb_TeamName";
            this.tb_TeamName.Size = new System.Drawing.Size(100, 20);
            this.tb_TeamName.TabIndex = 11;
            // 
            // tb_TeamCountry
            // 
            this.tb_TeamCountry.Location = new System.Drawing.Point(370, 121);
            this.tb_TeamCountry.Name = "tb_TeamCountry";
            this.tb_TeamCountry.Size = new System.Drawing.Size(100, 20);
            this.tb_TeamCountry.TabIndex = 12;
            // 
            // tb_TeamCity
            // 
            this.tb_TeamCity.Location = new System.Drawing.Point(370, 158);
            this.tb_TeamCity.Name = "tb_TeamCity";
            this.tb_TeamCity.Size = new System.Drawing.Size(100, 20);
            this.tb_TeamCity.TabIndex = 13;
            // 
            // tb_PlayerName
            // 
            this.tb_PlayerName.Location = new System.Drawing.Point(590, 81);
            this.tb_PlayerName.Name = "tb_PlayerName";
            this.tb_PlayerName.Size = new System.Drawing.Size(100, 20);
            this.tb_PlayerName.TabIndex = 14;
            // 
            // tb_PlayerNumber
            // 
            this.tb_PlayerNumber.Location = new System.Drawing.Point(590, 121);
            this.tb_PlayerNumber.Name = "tb_PlayerNumber";
            this.tb_PlayerNumber.Size = new System.Drawing.Size(100, 20);
            this.tb_PlayerNumber.TabIndex = 15;
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Location = new System.Drawing.Point(370, 201);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(75, 23);
            this.btn_AddTeam.TabIndex = 17;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.Location = new System.Drawing.Point(590, 201);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(75, 23);
            this.btn_AddPlayer.TabIndex = 18;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = true;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // btn_RemovePlayer
            // 
            this.btn_RemovePlayer.Location = new System.Drawing.Point(29, 316);
            this.btn_RemovePlayer.Name = "btn_RemovePlayer";
            this.btn_RemovePlayer.Size = new System.Drawing.Size(75, 23);
            this.btn_RemovePlayer.TabIndex = 19;
            this.btn_RemovePlayer.Text = "Remove";
            this.btn_RemovePlayer.UseVisualStyleBackColor = true;
            this.btn_RemovePlayer.Click += new System.EventHandler(this.btn_RemovePlayer_Click);
            // 
            // cb_Country
            // 
            this.cb_Country.FormattingEnabled = true;
            this.cb_Country.Location = new System.Drawing.Point(117, 81);
            this.cb_Country.Name = "cb_Country";
            this.cb_Country.Size = new System.Drawing.Size(121, 21);
            this.cb_Country.TabIndex = 20;
            this.cb_Country.SelectionChangeCommitted += new System.EventHandler(this.cb_Country_SelectionChangeCommitted);
            this.cb_Country.Click += new System.EventHandler(this.cb_Country_Click);
            // 
            // cbTeam
            // 
            this.cbTeam.FormattingEnabled = true;
            this.cbTeam.Location = new System.Drawing.Point(117, 121);
            this.cbTeam.Name = "cbTeam";
            this.cbTeam.Size = new System.Drawing.Size(121, 21);
            this.cbTeam.TabIndex = 21;
            this.cbTeam.SelectionChangeCommitted += new System.EventHandler(this.cbTeam_SelectionChangeCommited);
            // 
            // cb_PlayerPosition
            // 
            this.cb_PlayerPosition.FormattingEnabled = true;
            this.cb_PlayerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_PlayerPosition.Location = new System.Drawing.Point(590, 158);
            this.cb_PlayerPosition.Name = "cb_PlayerPosition";
            this.cb_PlayerPosition.Size = new System.Drawing.Size(100, 21);
            this.cb_PlayerPosition.TabIndex = 22;
            // 
            // lb_player
            // 
            this.lb_player.FormattingEnabled = true;
            this.lb_player.Location = new System.Drawing.Point(29, 176);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(209, 121);
            this.lb_player.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.cb_PlayerPosition);
            this.Controls.Add(this.cbTeam);
            this.Controls.Add(this.cb_Country);
            this.Controls.Add(this.btn_RemovePlayer);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.tb_PlayerNumber);
            this.Controls.Add(this.tb_PlayerName);
            this.Controls.Add(this.tb_TeamCity);
            this.Controls.Add(this.tb_TeamCountry);
            this.Controls.Add(this.tb_TeamName);
            this.Controls.Add(this.lbl_AddingPlayers);
            this.Controls.Add(this.lbl_AddingTeam);
            this.Controls.Add(this.lbl_PlayerPosition);
            this.Controls.Add(this.lbl_PlayerNumber);
            this.Controls.Add(this.lbl_PlayerName);
            this.Controls.Add(this.lbl_TeamCity);
            this.Controls.Add(this.lbl_TeamCountry);
            this.Controls.Add(this.lbl_TeamName);
            this.Controls.Add(this.lbl_Team);
            this.Controls.Add(this.lbl_Country);
            this.Controls.Add(this.lbl_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_SoccerTeamList;
        private System.Windows.Forms.Label lbl_Country;
        private System.Windows.Forms.Label lbl_Team;
        private System.Windows.Forms.Label lbl_TeamName;
        private System.Windows.Forms.Label lbl_TeamCountry;
        private System.Windows.Forms.Label lbl_TeamCity;
        private System.Windows.Forms.Label lbl_PlayerName;
        private System.Windows.Forms.Label lbl_PlayerNumber;
        private System.Windows.Forms.Label lbl_PlayerPosition;
        private System.Windows.Forms.Label lbl_AddingTeam;
        private System.Windows.Forms.Label lbl_AddingPlayers;
        private System.Windows.Forms.TextBox tb_TeamName;
        private System.Windows.Forms.TextBox tb_TeamCountry;
        private System.Windows.Forms.TextBox tb_TeamCity;
        private System.Windows.Forms.TextBox tb_PlayerName;
        private System.Windows.Forms.TextBox tb_PlayerNumber;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayer;
        private System.Windows.Forms.Button btn_RemovePlayer;
        private System.Windows.Forms.ComboBox cb_Country;
        private System.Windows.Forms.ComboBox cbTeam;
        private System.Windows.Forms.ComboBox cb_PlayerPosition;
        private System.Windows.Forms.ListBox lb_player;
    }
}

