﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome_week_4
{
    public partial class Formone : Form
    {
        DataTable dt;
        public Formone()
        {
            InitializeComponent();
            dt = new DataTable();
        }

        private void Formone_Load(object sender, EventArgs e)
        {
            panel1.BackColor= Color.FromArgb(160, 0, 0, 0);
            dt.Columns.Add("Negara");
            dt.Columns.Add("Team");
            dt.Columns.Add("No");
            dt.Columns.Add("nama");
            dt.Columns.Add("role");
            dt.Rows.Add("Indonesia", "Persebaya", "21", "Ernando Ari Sutaryadi", "GK");
            dt.Rows.Add("Indonesia", "Persebaya", "52", "Andhika Ramadhani", "GK");
            dt.Rows.Add("Indonesia", "Persebaya", "26", "Silva Paixao Yan Victor", "DF");
            dt.Rows.Add("Indonesia", "Persebaya", "42", "Arief Catur Prasetya", "DF");
            dt.Rows.Add("Indonesia", "Persebaya", "5", "Dusan Stevanovic", "DF");
            dt.Rows.Add("Indonesia", "Persebaya", "96", "Muhammad Hidayat", "MF");
            dt.Rows.Add("Indonesia", "Persebaya", "8", "Andre Oktaviansyah", "MF");
            dt.Rows.Add("Indonesia", "Persebaya", "28", "Alfan Suaib", "MF");
            dt.Rows.Add("Indonesia", "Persebaya", "30", "Robson Duarte", "FW");
            dt.Rows.Add("Indonesia", "Persebaya", "9", "Paulo Henrique", "FW");
            dt.Rows.Add("Indonesia", "Persebaya", "99", "Bruno Moreira Soares", "FW");
            dt.Rows.Add("Indonesia", "Arema FC", "23", "Teguh Amirrudin", "GK");
            dt.Rows.Add("Indonesia", "Arema FC", "22", "Dicki Agung", "GK");
            dt.Rows.Add("Indonesia", "Arema FC", "5", "Bagas Adi", "DF");
            dt.Rows.Add("Indonesia", "Arema FC", "4", "Syaeful Anwar", "DF");
            dt.Rows.Add("Indonesia", "Arema FC", "3", "Bayu Aji", "DF");
            dt.Rows.Add("Indonesia", "Arema FC", "14", "Jayus Hariono", "MF");
            dt.Rows.Add("Indonesia", "Arema FC", "8", "Arkhan Fikri", "MF");
            dt.Rows.Add("Indonesia", "Arema FC", "19", "Achmad Maulana", "MF");
            dt.Rows.Add("Indonesia", "Arema FC", "10", "Muhammad Rafli", "FW");
            dt.Rows.Add("Indonesia", "Arema FC", "17", "Ginanjar Wahyu", "FW");
            dt.Rows.Add("Indonesia", "Arema FC", "86", "Greg Nwokolo", "FW");
            dt.Rows.Add("Britania Raya", "Liverpool", "1", "Alisson Becker", "GK");
            dt.Rows.Add("Britania Raya", "Liverpool", "13", "Adrian", "GK");
            dt.Rows.Add("Britania Raya", "Liverpool", "2", "Joe Gomez", "DF");
            dt.Rows.Add("Britania Raya", "Liverpool", "5", "Ibrahima Konate", "DF");
            dt.Rows.Add("Britania Raya", "Liverpool", "4", "Virgil Van Djik", "DF");
            dt.Rows.Add("Britania Raya", "Liverpool", "2", "Wateru Endo", "MF");
            dt.Rows.Add("Britania Raya", "Liverpool", "6", "Thiago Alcantara", "MF");
            dt.Rows.Add("Britania Raya", "Liverpool", "8", "Dominik Szobozslai", "MF");
            dt.Rows.Add("Britania Raya", "Liverpool", "7", "Luis Diaz", "FW");
            dt.Rows.Add("Britania Raya", "Liverpool", "9", "Darwin Nunez", "FW");
            dt.Rows.Add("Britania Raya", "Liverpool", "11", "Mohamed Salah", "FW");
        }

        private void cb_country_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < dt.Rows.Count; i++)
            {
                if (!cb_country.Items.Contains(dt.Rows[i][0]))
                {
                    cb_country.Items.Add(dt.Rows[i][0]);
                }
            }
            lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
        }

        private void cb_country_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            cb_team.Text = string.Empty;
            lb_player.Items.Clear();
            lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][0] == cb_country.SelectedItem)
                {
                    if (!cb_team.Items.Contains(dt.Rows[i][1]))
                    {
                        cb_team.Items.Add(dt.Rows[i][1]);
                    }
                }
            }
            lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
        }

        private void cb_team_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lb_player.Items.Clear();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][1] == cb_team.SelectedItem)
                {
                    lb_player.Items.Add("(" + dt.Rows[i][2] + ") " + dt.Rows[i][3] + ". " + dt.Rows[i][4]);
                }
            }
            lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
        }

        private void button_remove_Click(object sender, EventArgs e)
        {
            if (lb_player.Items.Count <= 11)
            {
                MessageBox.Show("Harus memiliki 11 player untuk menggunakan fitur Remove", "Warning!");

            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1] == cb_team.SelectedItem)
                    {
                        dt.Rows.RemoveAt(lb_player.SelectedIndex + i);
                        lb_player.Items.Remove(lb_player.SelectedItem);
                        break;
                    }
                }
            }
            lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
        }

        private void button_add_team_Click(object sender, EventArgs e)
        {
            if (tb_team_name.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi nama Tim");
            }
            else if (tb_team_country.Text.Length==0)
            {
                MessageBox.Show("belum mengisi negara asal");
            }
            else if (tb_team_city.Text.Length==0)
            {
                MessageBox.Show("belum mengisi asal kota");
            }
            else
            {
                bool ada = false;
                for(int i = 0;i < dt.Rows.Count; i++)
                {
                    if (tb_team_name.Text == dt.Rows[i][1].ToString())
                    {
                        MessageBox.Show("Nama tim sudah digunakan");
                        ada = true;
                        break;
                    }
                }
                if (ada == false)
                {
                    dt.Rows.Add(tb_team_country.Text, tb_team_name.Text,"","","");
                    tb_team_name.Clear();
                    tb_team_country.Clear();
                    tb_team_city.Clear();
                    lb_player.Items.Clear();
                    cb_country.Text = string.Empty;
                    cb_team.Items.Clear();
                    cb_team.Text = string.Empty;
                    lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
                }
            }
        }

        private void button_add_player_Click(object sender, EventArgs e)
        {
            if (cb_team.Text.Length == 0)
            {
                MessageBox.Show("Pilih Tim terlebih dahulu sebelum menambahkan pemain");
            }
            else if (tb_player_name.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi nama pemain");
            }
            else if (tb_player_number.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi nomor pemain");
            }
            else if (cb_role.Text.Length == 0)
            {
                MessageBox.Show("belum mengisi posisi");
            }
            else
            {
                bool ada = false;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (tb_player_name.Text == dt.Rows[i][3].ToString())
                    {
                        MessageBox.Show("Nama pemain tidak boleh sama");
                        ada = true;
                        break;
                    }
                }
                if (ada == false)
                {
                    dt.Rows.Add(cb_country.SelectedItem.ToString(),cb_team.SelectedItem.ToString(),tb_player_number.Text.ToString(),tb_player_name.Text.ToString(),cb_role.SelectedItem.ToString());
                    lb_player.Items.Clear();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (dt.Rows[i][1] == cb_team.SelectedItem)
                        {
                            lb_player.Items.Add("(" + dt.Rows[i][2] + ") " + dt.Rows[i][3] + ". " + dt.Rows[i][4]);
                        }
                    }
                    lbl_playertotal.Text = "Jumlah Pemain = " + lb_player.Items.Count;
                    tb_player_name.Clear();
                    tb_player_number.Clear();
                    cb_role.Text = string.Empty;
                }
            }
        }
    }
}
