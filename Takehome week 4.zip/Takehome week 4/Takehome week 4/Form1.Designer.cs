﻿namespace Takehome_week_4
{
    partial class Formone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_add_team = new System.Windows.Forms.Button();
            this.lb_player = new System.Windows.Forms.ListBox();
            this.lbl_socer = new System.Windows.Forms.Label();
            this.button_remove = new System.Windows.Forms.Button();
            this.lbl_Country = new System.Windows.Forms.Label();
            this.lbl_team = new System.Windows.Forms.Label();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.lbl_add_team = new System.Windows.Forms.Label();
            this.lbl_add_name = new System.Windows.Forms.Label();
            this.lbl_add_country = new System.Windows.Forms.Label();
            this.lbl_add_city = new System.Windows.Forms.Label();
            this.tb_team_name = new System.Windows.Forms.TextBox();
            this.tb_team_country = new System.Windows.Forms.TextBox();
            this.tb_team_city = new System.Windows.Forms.TextBox();
            this.tb_player_number = new System.Windows.Forms.TextBox();
            this.tb_player_name = new System.Windows.Forms.TextBox();
            this.lbl_player_position = new System.Windows.Forms.Label();
            this.lbl_player_number = new System.Windows.Forms.Label();
            this.lbl_player_name = new System.Windows.Forms.Label();
            this.lbl_add_player = new System.Windows.Forms.Label();
            this.button_add_player = new System.Windows.Forms.Button();
            this.cb_role = new System.Windows.Forms.ComboBox();
            this.panels = new System.Windows.Forms.Panel();
            this.lbl_playertotal = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_add_team
            // 
            this.button_add_team.Location = new System.Drawing.Point(605, 231);
            this.button_add_team.Name = "button_add_team";
            this.button_add_team.Size = new System.Drawing.Size(111, 35);
            this.button_add_team.TabIndex = 0;
            this.button_add_team.Text = "Add";
            this.button_add_team.UseVisualStyleBackColor = true;
            this.button_add_team.Click += new System.EventHandler(this.button_add_team_Click);
            // 
            // lb_player
            // 
            this.lb_player.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_player.FormattingEnabled = true;
            this.lb_player.ItemHeight = 20;
            this.lb_player.Location = new System.Drawing.Point(6, 5);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(414, 384);
            this.lb_player.TabIndex = 1;
            // 
            // lbl_socer
            // 
            this.lbl_socer.AutoSize = true;
            this.lbl_socer.BackColor = System.Drawing.Color.Transparent;
            this.lbl_socer.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_socer.ForeColor = System.Drawing.Color.White;
            this.lbl_socer.Location = new System.Drawing.Point(431, 5);
            this.lbl_socer.Name = "lbl_socer";
            this.lbl_socer.Size = new System.Drawing.Size(128, 16);
            this.lbl_socer.TabIndex = 2;
            this.lbl_socer.Text = "Soccer Team List";
            // 
            // button_remove
            // 
            this.button_remove.Location = new System.Drawing.Point(6, 399);
            this.button_remove.Name = "button_remove";
            this.button_remove.Size = new System.Drawing.Size(179, 39);
            this.button_remove.TabIndex = 3;
            this.button_remove.Text = "Remove";
            this.button_remove.UseVisualStyleBackColor = true;
            this.button_remove.Click += new System.EventHandler(this.button_remove_Click);
            // 
            // lbl_Country
            // 
            this.lbl_Country.AutoSize = true;
            this.lbl_Country.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Country.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Country.ForeColor = System.Drawing.Color.White;
            this.lbl_Country.Location = new System.Drawing.Point(431, 31);
            this.lbl_Country.Name = "lbl_Country";
            this.lbl_Country.Size = new System.Drawing.Size(116, 16);
            this.lbl_Country.TabIndex = 4;
            this.lbl_Country.Text = "Choose Country";
            // 
            // lbl_team
            // 
            this.lbl_team.AutoSize = true;
            this.lbl_team.BackColor = System.Drawing.Color.Transparent;
            this.lbl_team.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_team.ForeColor = System.Drawing.Color.White;
            this.lbl_team.Location = new System.Drawing.Point(431, 59);
            this.lbl_team.Name = "lbl_team";
            this.lbl_team.Size = new System.Drawing.Size(104, 16);
            this.lbl_team.TabIndex = 5;
            this.lbl_team.Text = "Choose Team";
            // 
            // cb_country
            // 
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Location = new System.Drawing.Point(557, 28);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(209, 24);
            this.cb_country.TabIndex = 6;
            this.cb_country.SelectionChangeCommitted += new System.EventHandler(this.cb_country_SelectionChangeCommitted);
            this.cb_country.Click += new System.EventHandler(this.cb_country_Click);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Items.AddRange(new object[] {
            " "});
            this.cb_team.Location = new System.Drawing.Point(557, 59);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(209, 24);
            this.cb_team.TabIndex = 7;
            this.cb_team.SelectionChangeCommitted += new System.EventHandler(this.cb_team_SelectionChangeCommitted);
            // 
            // lbl_add_team
            // 
            this.lbl_add_team.AutoSize = true;
            this.lbl_add_team.BackColor = System.Drawing.Color.Transparent;
            this.lbl_add_team.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add_team.ForeColor = System.Drawing.Color.White;
            this.lbl_add_team.Location = new System.Drawing.Point(431, 117);
            this.lbl_add_team.Name = "lbl_add_team";
            this.lbl_add_team.Size = new System.Drawing.Size(100, 16);
            this.lbl_add_team.TabIndex = 8;
            this.lbl_add_team.Text = "Adding Team";
            // 
            // lbl_add_name
            // 
            this.lbl_add_name.AutoSize = true;
            this.lbl_add_name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_add_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add_name.ForeColor = System.Drawing.Color.White;
            this.lbl_add_name.Location = new System.Drawing.Point(435, 148);
            this.lbl_add_name.Name = "lbl_add_name";
            this.lbl_add_name.Size = new System.Drawing.Size(92, 16);
            this.lbl_add_name.TabIndex = 9;
            this.lbl_add_name.Text = "Team Name";
            // 
            // lbl_add_country
            // 
            this.lbl_add_country.AutoSize = true;
            this.lbl_add_country.BackColor = System.Drawing.Color.Transparent;
            this.lbl_add_country.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add_country.ForeColor = System.Drawing.Color.White;
            this.lbl_add_country.Location = new System.Drawing.Point(435, 177);
            this.lbl_add_country.Name = "lbl_add_country";
            this.lbl_add_country.Size = new System.Drawing.Size(103, 16);
            this.lbl_add_country.TabIndex = 10;
            this.lbl_add_country.Text = "Team Country";
            // 
            // lbl_add_city
            // 
            this.lbl_add_city.AutoSize = true;
            this.lbl_add_city.BackColor = System.Drawing.Color.Transparent;
            this.lbl_add_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add_city.ForeColor = System.Drawing.Color.White;
            this.lbl_add_city.Location = new System.Drawing.Point(435, 206);
            this.lbl_add_city.Name = "lbl_add_city";
            this.lbl_add_city.Size = new System.Drawing.Size(77, 16);
            this.lbl_add_city.TabIndex = 11;
            this.lbl_add_city.Text = "Team City";
            // 
            // tb_team_name
            // 
            this.tb_team_name.Location = new System.Drawing.Point(557, 141);
            this.tb_team_name.Name = "tb_team_name";
            this.tb_team_name.Size = new System.Drawing.Size(209, 22);
            this.tb_team_name.TabIndex = 12;
            // 
            // tb_team_country
            // 
            this.tb_team_country.Location = new System.Drawing.Point(557, 169);
            this.tb_team_country.Name = "tb_team_country";
            this.tb_team_country.Size = new System.Drawing.Size(209, 22);
            this.tb_team_country.TabIndex = 13;
            // 
            // tb_team_city
            // 
            this.tb_team_city.Location = new System.Drawing.Point(557, 203);
            this.tb_team_city.Name = "tb_team_city";
            this.tb_team_city.Size = new System.Drawing.Size(209, 22);
            this.tb_team_city.TabIndex = 14;
            // 
            // tb_player_number
            // 
            this.tb_player_number.Location = new System.Drawing.Point(557, 315);
            this.tb_player_number.Name = "tb_player_number";
            this.tb_player_number.Size = new System.Drawing.Size(209, 22);
            this.tb_player_number.TabIndex = 21;
            // 
            // tb_player_name
            // 
            this.tb_player_name.Location = new System.Drawing.Point(557, 287);
            this.tb_player_name.Name = "tb_player_name";
            this.tb_player_name.Size = new System.Drawing.Size(209, 22);
            this.tb_player_name.TabIndex = 20;
            // 
            // lbl_player_position
            // 
            this.lbl_player_position.AutoSize = true;
            this.lbl_player_position.BackColor = System.Drawing.Color.Transparent;
            this.lbl_player_position.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_player_position.ForeColor = System.Drawing.Color.White;
            this.lbl_player_position.Location = new System.Drawing.Point(435, 352);
            this.lbl_player_position.Name = "lbl_player_position";
            this.lbl_player_position.Size = new System.Drawing.Size(112, 16);
            this.lbl_player_position.TabIndex = 19;
            this.lbl_player_position.Text = "Player Position";
            // 
            // lbl_player_number
            // 
            this.lbl_player_number.AutoSize = true;
            this.lbl_player_number.BackColor = System.Drawing.Color.Transparent;
            this.lbl_player_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_player_number.ForeColor = System.Drawing.Color.White;
            this.lbl_player_number.Location = new System.Drawing.Point(435, 323);
            this.lbl_player_number.Name = "lbl_player_number";
            this.lbl_player_number.Size = new System.Drawing.Size(110, 16);
            this.lbl_player_number.TabIndex = 18;
            this.lbl_player_number.Text = "Player Number";
            // 
            // lbl_player_name
            // 
            this.lbl_player_name.AutoSize = true;
            this.lbl_player_name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_player_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_player_name.ForeColor = System.Drawing.Color.White;
            this.lbl_player_name.Location = new System.Drawing.Point(435, 294);
            this.lbl_player_name.Name = "lbl_player_name";
            this.lbl_player_name.Size = new System.Drawing.Size(97, 16);
            this.lbl_player_name.TabIndex = 17;
            this.lbl_player_name.Text = "Player Name";
            // 
            // lbl_add_player
            // 
            this.lbl_add_player.AutoSize = true;
            this.lbl_add_player.BackColor = System.Drawing.Color.Transparent;
            this.lbl_add_player.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_add_player.ForeColor = System.Drawing.Color.White;
            this.lbl_add_player.Location = new System.Drawing.Point(431, 263);
            this.lbl_add_player.Name = "lbl_add_player";
            this.lbl_add_player.Size = new System.Drawing.Size(100, 16);
            this.lbl_add_player.TabIndex = 16;
            this.lbl_add_player.Text = "Adding Team";
            // 
            // button_add_player
            // 
            this.button_add_player.Location = new System.Drawing.Point(605, 377);
            this.button_add_player.Name = "button_add_player";
            this.button_add_player.Size = new System.Drawing.Size(111, 35);
            this.button_add_player.TabIndex = 15;
            this.button_add_player.Text = "Add";
            this.button_add_player.UseVisualStyleBackColor = true;
            this.button_add_player.Click += new System.EventHandler(this.button_add_player_Click);
            // 
            // cb_role
            // 
            this.cb_role.FormattingEnabled = true;
            this.cb_role.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_role.Location = new System.Drawing.Point(557, 344);
            this.cb_role.Name = "cb_role";
            this.cb_role.Size = new System.Drawing.Size(209, 24);
            this.cb_role.TabIndex = 22;
            // 
            // panels
            // 
            this.panels.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panels.AutoSize = true;
            this.panels.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panels.BackColor = System.Drawing.Color.Transparent;
            this.panels.Location = new System.Drawing.Point(6, 4);
            this.panels.Name = "panels";
            this.panels.Size = new System.Drawing.Size(0, 0);
            this.panels.TabIndex = 24;
            // 
            // lbl_playertotal
            // 
            this.lbl_playertotal.AutoSize = true;
            this.lbl_playertotal.BackColor = System.Drawing.Color.Transparent;
            this.lbl_playertotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_playertotal.ForeColor = System.Drawing.Color.White;
            this.lbl_playertotal.Location = new System.Drawing.Point(191, 405);
            this.lbl_playertotal.Name = "lbl_playertotal";
            this.lbl_playertotal.Size = new System.Drawing.Size(217, 29);
            this.lbl_playertotal.TabIndex = 25;
            this.lbl_playertotal.Text = "Jumlah Pemain = 0";
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.lbl_playertotal);
            this.panel1.Controls.Add(this.lb_player);
            this.panel1.Controls.Add(this.cb_role);
            this.panel1.Controls.Add(this.button_add_team);
            this.panel1.Controls.Add(this.tb_player_number);
            this.panel1.Controls.Add(this.lbl_socer);
            this.panel1.Controls.Add(this.tb_player_name);
            this.panel1.Controls.Add(this.button_remove);
            this.panel1.Controls.Add(this.lbl_player_position);
            this.panel1.Controls.Add(this.lbl_Country);
            this.panel1.Controls.Add(this.lbl_player_number);
            this.panel1.Controls.Add(this.lbl_team);
            this.panel1.Controls.Add(this.lbl_player_name);
            this.panel1.Controls.Add(this.cb_country);
            this.panel1.Controls.Add(this.lbl_add_player);
            this.panel1.Controls.Add(this.cb_team);
            this.panel1.Controls.Add(this.button_add_player);
            this.panel1.Controls.Add(this.lbl_add_team);
            this.panel1.Controls.Add(this.tb_team_city);
            this.panel1.Controls.Add(this.lbl_add_name);
            this.panel1.Controls.Add(this.tb_team_country);
            this.panel1.Controls.Add(this.lbl_add_country);
            this.panel1.Controls.Add(this.tb_team_name);
            this.panel1.Controls.Add(this.lbl_add_city);
            this.panel1.Location = new System.Drawing.Point(6, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(786, 444);
            this.panel1.TabIndex = 26;
            // 
            // Formone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Takehome_week_4.Properties.Resources.wallpaperflare_com_wallpaper_5_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(942, 534);
            this.Controls.Add(this.panels);
            this.Controls.Add(this.panel1);
            this.Name = "Formone";
            this.Text = "Soccer Manager by Adelio";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Formone_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_add_team;
        private System.Windows.Forms.ListBox lb_player;
        private System.Windows.Forms.Label lbl_socer;
        private System.Windows.Forms.Button button_remove;
        private System.Windows.Forms.Label lbl_Country;
        private System.Windows.Forms.Label lbl_team;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label lbl_add_team;
        private System.Windows.Forms.Label lbl_add_name;
        private System.Windows.Forms.Label lbl_add_country;
        private System.Windows.Forms.Label lbl_add_city;
        private System.Windows.Forms.TextBox tb_team_name;
        private System.Windows.Forms.TextBox tb_team_country;
        private System.Windows.Forms.TextBox tb_team_city;
        private System.Windows.Forms.TextBox tb_player_number;
        private System.Windows.Forms.TextBox tb_player_name;
        private System.Windows.Forms.Label lbl_player_position;
        private System.Windows.Forms.Label lbl_player_number;
        private System.Windows.Forms.Label lbl_player_name;
        private System.Windows.Forms.Label lbl_add_player;
        private System.Windows.Forms.Button button_add_player;
        private System.Windows.Forms.ComboBox cb_role;
        private System.Windows.Forms.Panel panels;
        private System.Windows.Forms.Label lbl_playertotal;
        private System.Windows.Forms.Panel panel1;
    }
}

